
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		newscenecreator
	 *	@date 		Tuesday 25th of April 2023 06:37:22 PM
	 *	@title 		Add Scene
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.figma;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.TextView;
import android.widget.ImageView;

public class newscenecreator_activity extends Activity {

	
	private View _bg__newscenecreator_ek2;
	private TextView new_scene;
	private View rectangle_1;
	private TextView add_routine;
	private View rectangle_2;
	private TextView recently_used;
	private ImageView rectangle_3;
	private View rectangle_4;
	private TextView look_for_intruders;
	private ImageView notification_important;
	private ImageView nightlife;
	private TextView play_music;
	private TextView set_scene_duration;
	private View rectangle_5;
	private ImageView rectangle_7;
	private TextView __;
	private View rectangle_6;
	private TextView ___ek1;
	private TextView start;
	private TextView end;
	private ImageView reply;
	private ImageView add_box;
	private ImageView check_circle;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.newscenecreator);

		
		_bg__newscenecreator_ek2 = (View) findViewById(R.id._bg__newscenecreator_ek2);
		new_scene = (TextView) findViewById(R.id.new_scene);
		rectangle_1 = (View) findViewById(R.id.rectangle_1);
		add_routine = (TextView) findViewById(R.id.add_routine);
		rectangle_2 = (View) findViewById(R.id.rectangle_2);
		recently_used = (TextView) findViewById(R.id.recently_used);
		rectangle_3 = (ImageView) findViewById(R.id.rectangle_3);
		rectangle_4 = (View) findViewById(R.id.rectangle_4);
		look_for_intruders = (TextView) findViewById(R.id.look_for_intruders);
		notification_important = (ImageView) findViewById(R.id.notification_important);
		nightlife = (ImageView) findViewById(R.id.nightlife);
		play_music = (TextView) findViewById(R.id.play_music);
		set_scene_duration = (TextView) findViewById(R.id.set_scene_duration);
		rectangle_5 = (View) findViewById(R.id.rectangle_5);
		rectangle_7 = (ImageView) findViewById(R.id.rectangle_7);
		__ = (TextView) findViewById(R.id.__);
		rectangle_6 = (View) findViewById(R.id.rectangle_6);
		___ek1 = (TextView) findViewById(R.id.___ek1);
		start = (TextView) findViewById(R.id.start);
		end = (TextView) findViewById(R.id.end);
		reply = (ImageView) findViewById(R.id.reply);
		add_box = (ImageView) findViewById(R.id.add_box);
		check_circle = (ImageView) findViewById(R.id.check_circle);
	
		
		//custom code goes here
	
	}
}
	
	