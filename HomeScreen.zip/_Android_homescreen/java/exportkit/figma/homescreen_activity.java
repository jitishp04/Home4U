
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		homescreen
	 *	@date 		Thursday 27th of April 2023 10:03:31 AM
	 *	@title 		Home Screen
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.figma;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.TextView;
import android.widget.ImageView;

public class homescreen_activity extends Activity {

	
	private View _bg__homescreen_ek2;
	private View rectangle_1;
	private TextView create_a_scene_that_controls_your_home4u_device_;
	private View rectangle_2;
	private View rectangle_5;
	private TextView remotely_disable_your_alarm;
	private View rectangle_4;
	private View rectangle_6;
	private TextView disable_alarm;
	private TextView connect_your_phone_to_the_device_and_play_music;
	private View rectangle_3;
	private TextView play_music;
	private TextView create_a_scene;
	private ImageView media_bluetooth_on;
	private ImageView alarm_off;
	private ImageView router;
	private ImageView sunflower_1;
	private View rectangle_7;
	private TextView home4u;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.homescreen);

		
		_bg__homescreen_ek2 = (View) findViewById(R.id._bg__homescreen_ek2);
		rectangle_1 = (View) findViewById(R.id.rectangle_1);
		create_a_scene_that_controls_your_home4u_device_ = (TextView) findViewById(R.id.create_a_scene_that_controls_your_home4u_device_);
		rectangle_2 = (View) findViewById(R.id.rectangle_2);
		rectangle_5 = (View) findViewById(R.id.rectangle_5);
		remotely_disable_your_alarm = (TextView) findViewById(R.id.remotely_disable_your_alarm);
		rectangle_4 = (View) findViewById(R.id.rectangle_4);
		rectangle_6 = (View) findViewById(R.id.rectangle_6);
		disable_alarm = (TextView) findViewById(R.id.disable_alarm);
		connect_your_phone_to_the_device_and_play_music = (TextView) findViewById(R.id.connect_your_phone_to_the_device_and_play_music);
		rectangle_3 = (View) findViewById(R.id.rectangle_3);
		play_music = (TextView) findViewById(R.id.play_music);
		create_a_scene = (TextView) findViewById(R.id.create_a_scene);
		media_bluetooth_on = (ImageView) findViewById(R.id.media_bluetooth_on);
		alarm_off = (ImageView) findViewById(R.id.alarm_off);
		router = (ImageView) findViewById(R.id.router);
		sunflower_1 = (ImageView) findViewById(R.id.sunflower_1);
		rectangle_7 = (View) findViewById(R.id.rectangle_7);
		home4u = (TextView) findViewById(R.id.home4u);
	
		
		//custom code goes here
	
	}
}
	
	