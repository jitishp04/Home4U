
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		scenedisplay
	 *	@date 		Tuesday 25th of April 2023 06:38:39 PM
	 *	@title 		Scene Manager
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.figma;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.TextView;
import android.widget.ImageView;

public class scenedisplay_activity extends Activity {

	
	private View _bg__scenedisplay_ek2;
	private TextView scenes;
	private TextView dictate_how_the_system_reacts_to_conditions_;
	private TextView current_scenes;
	private ImageView rectangle_1;
	private View rectangle_2;
	private TextView im_home;
	private TextView lockdown_mode;
	private ImageView online_prediction;
	private ImageView notification_important;
	private ImageView nightlife;
	private ImageView emoji_objects;
	private ImageView arrow_forward_ios;
	private ImageView arrow_forward_ios_ek1;
	private ImageView add;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.scenedisplay);

		
		_bg__scenedisplay_ek2 = (View) findViewById(R.id._bg__scenedisplay_ek2);
		scenes = (TextView) findViewById(R.id.scenes);
		dictate_how_the_system_reacts_to_conditions_ = (TextView) findViewById(R.id.dictate_how_the_system_reacts_to_conditions_);
		current_scenes = (TextView) findViewById(R.id.current_scenes);
		rectangle_1 = (ImageView) findViewById(R.id.rectangle_1);
		rectangle_2 = (View) findViewById(R.id.rectangle_2);
		im_home = (TextView) findViewById(R.id.im_home);
		lockdown_mode = (TextView) findViewById(R.id.lockdown_mode);
		online_prediction = (ImageView) findViewById(R.id.online_prediction);
		notification_important = (ImageView) findViewById(R.id.notification_important);
		nightlife = (ImageView) findViewById(R.id.nightlife);
		emoji_objects = (ImageView) findViewById(R.id.emoji_objects);
		arrow_forward_ios = (ImageView) findViewById(R.id.arrow_forward_ios);
		arrow_forward_ios_ek1 = (ImageView) findViewById(R.id.arrow_forward_ios_ek1);
		add = (ImageView) findViewById(R.id.add);
	
		
		//custom code goes here
	
	}
}
	
	